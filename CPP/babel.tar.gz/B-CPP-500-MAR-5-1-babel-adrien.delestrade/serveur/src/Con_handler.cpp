/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Con_handler
*/

#include "../include/Con_handler.hpp"

Con_handler::Con_handler(boost::asio::io_service& io_service): io_service_(io_service), sock(io_service)
{
    _actionServ = new Action();
}

Con_handler::~Con_handler()
{
}

boost::asio::ip::tcp::socket& Con_handler::socket() {
    return sock;
}

void Con_handler::startRead() {
    sock.async_read_some(
        boost::asio::buffer(data, max_length),
        boost::bind(&Con_handler::handle_read,
        shared_from_this(),
        boost::asio::placeholders::error,
        boost::asio::placeholders::bytes_transferred));
}

void Con_handler::write() {
    sock.async_write_some(
        boost::asio::buffer(message, max_length),
        boost::bind(&Con_handler::handle_write,
        shared_from_this(),
        boost::asio::placeholders::error,
        boost::asio::placeholders::bytes_transferred));
}

void Con_handler::handle_read(const boost::system::error_code& err, size_t bytes_transferred) {
    if (!err) {
        message = _actionServ->parseCmd(data);
        //std::cout << data << std::endl;
        int i = -1;
        while (++i != 1024)
            data[i] = 0;
        write();
        startRead();
    } else if (err == boost::asio::error::eof || err == boost::asio::error::connection_reset) {
        std::cout << "client disconnected" << std::endl;
        //message = _actionServ->parseCmd("client_disconnected");
         sock.close();
    } else {
         std::cerr << "error: " << err.message() << std::endl;
         sock.close();
    }
}

void Con_handler::handle_write(const boost::system::error_code& err, size_t bytes_transferred) {
    if (!err) {
       std::cout << "Server sent Hello message!"<< std::endl;
    } else {
       std::cerr << "error: " << err.message() << std::endl;
       sock.close();
    }
}