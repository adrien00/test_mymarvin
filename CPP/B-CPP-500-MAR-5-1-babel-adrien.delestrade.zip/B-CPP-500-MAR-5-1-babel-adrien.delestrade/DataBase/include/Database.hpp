/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Database
*/

#ifndef DATABASE_HPP_
#define DATABASE_HPP_

#include <cstring>
#include "../IDatabase.hpp"

class Database : public IDatabase{
    public:
        Database();
        ~Database() override;
        std::string takeUserID(std::string);
        int setNewUser(std::string UserName, std::string UserID, std::string Password) override;
        void setState(std::string Username, std::string) override;
        void saveDB()override;
        void loadSaveDB() override;
        void parser(std::list<std::string> Save)override;
        int UserAlreadyexist(std::string) override;
        std::string Idgenerate() override;
        std::string getUSerPassWord(std::string UserID) override;
        void loadUser(std::string save) override;
        void loadState(std::string save, std::string Username) override;
        void clearDB() override;
        std::string list_users() override;
        void SaveState(User *user, std::ofstream &myfile) override;
        void SaveContact(User *user, std::ofstream &myfile) override;
        std::string UserDisconect(std::string Username) override;
        void loadContact(std::string save, std::string Username) override;
        void addContact(std::string username, std::string ContactName) override;
        bool alreadyconnected(std::string Username) override;
    protected:
    private:

    // Cette liste contien tous les user, on a une map qvec l'id de l'user, et un pointeur sur un objet User.
    std::map<std::string, User*> _users;

};

std::list<std::string> split(std::string strToSplit, char delimeter);

#endif /* !DATABASE_HPP_ */
