/*
** EPITECH PROJECT, 2020
** babel
** File description:
** Mainserv
*/

#ifndef MAINSERV_HPP_
#define MAINSERV_HPP_
#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/thread.hpp>
#include <list>
#include <boost/enable_shared_from_this.hpp>
#include "Con_handler.hpp"


class Mainserv {
    public:
        Mainserv(boost::asio::io_service &io_service);
        void handle_accept(Con_handler::pointer connection, const boost::system::error_code& err);
        void loop(void);
        void readclient();
        void sendToAll(std::string);
        void checkSend(std::string);
        ~Mainserv();

    protected:
    private:
        boost::asio::io_service& io_service_;
        boost::asio::ip::tcp::acceptor acceptor_;
        boost::thread thread_;
        boost::asio::io_service::work *worker_;
        void start_accept();
        std::list<Con_handler::pointer> _socket;
        Iactions *_actionServ;
        void thread_function(void);
};

#endif /* !MAINSERV_HPP_ */