#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QTcpSocket>
#include <QDebug>
#include <iostream>
#include <QInputDialog>
#include <QWidget>

#include "doublelist.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    void call_alert(std::string caller);
     void contact_alert(std::string asker);
    void construct_users_list(std::vector<std::string> datas_vec);
    void set_user_info(QString username);
    void PositiveAnswerToCall(std::string caller);
    void NegativeAnswerToCall(std::string caller);
    void NegativeAnswerToContact(std::string caller);
    void closeMainWindow();


    ~MainWindow();


private slots:

    void on_ContactGestion_clicked();

    void on_Exit_clicked();

    void on_CallBtn_clicked();

    void on_UpdateContactBtn_clicked();

private:
    DoubleList *doublelist;
    Ui::MainWindow *ui;
    QList<QString> QList_users;
    Ui::MainWindow *UserContactList;
    Ui::MainWindow *UserNameL;
    QString user_name;


};

#endif // MAINWINDOW_H
