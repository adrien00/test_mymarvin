/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** User
*/

#include "../include/User.hpp"

User::User()
{
}

User::~User()
{
}

void User::setUsername(std::string Username)
{
    _userName = Username;
}

std::string User::getUsername()
{
    return _userName;
}

void User::setUserID(std::string UserID)
{
    _userID = UserID;
}

void User::setPassWord(std::string PassWord)
{
    _PassWord = PassWord;
}

std::string User::getPassword()
{
    return _PassWord;
}

std::string User::getUserID()
{
    return _userID;
}

std::string User::getConectionStatement()
{
    return _ConectionStatement;
}

void User::setConectionStatement(std::string ConectionStatement)
{
    _ConectionStatement = ConectionStatement;
}
