/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Con_handler
*/

#ifndef Con_handler_HPP_
#define Con_handler_HPP_
#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/enable_shared_from_this.hpp>
#include "IconHandler.hpp"
#include "Action.hpp"

class Con_handler : public boost::enable_shared_from_this<Con_handler> , public IconHandler{
    public:
        Con_handler(boost::asio::io_service& io_service);
		typedef boost::shared_ptr<Con_handler> pointer;
		boost::asio::ip::tcp::socket& socket();
		void startRead() override;
		void write(std::string str) override;
		void handle_read(const boost::system::error_code& err, size_t bytes_transferred) override;
		void handle_write(const boost::system::error_code& err, size_t bytes_transferred) override;
        std::string getData() override;

        bool isConnected() override;
        ~Con_handler() override;

    protected:
    private:
	boost::asio::io_service &io_service_;
	boost::asio::ip::tcp::socket sock;
  	std::string message="I am Server !\n";
  	enum { max_length = 1024 };
  	char data[max_length];
    Iactions *_actionServ;
    bool _connected;
};

#endif /* !Con_handler_HPP_ */