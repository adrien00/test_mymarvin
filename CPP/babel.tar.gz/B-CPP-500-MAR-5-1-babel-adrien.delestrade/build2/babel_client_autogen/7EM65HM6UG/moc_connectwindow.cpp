/****************************************************************************
** Meta object code from reading C++ file 'connectwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../client/connectwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'connectwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Connectwindow_t {
    QByteArrayData data[12];
    char stringdata0[150];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Connectwindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Connectwindow_t qt_meta_stringdata_Connectwindow = {
    {
QT_MOC_LITERAL(0, 0, 13), // "Connectwindow"
QT_MOC_LITERAL(1, 14, 11), // "onReadyRead"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 17), // "on_LogInB_clicked"
QT_MOC_LITERAL(4, 45, 15), // "on_Exit_clicked"
QT_MOC_LITERAL(5, 61, 9), // "parse_cmd"
QT_MOC_LITERAL(6, 71, 24), // "std::vector<std::string>"
QT_MOC_LITERAL(7, 96, 9), // "datas_vec"
QT_MOC_LITERAL(8, 106, 13), // "log_in_errors"
QT_MOC_LITERAL(9, 120, 16), // "open_main_window"
QT_MOC_LITERAL(10, 137, 4), // "hope"
QT_MOC_LITERAL(11, 142, 7) // "request"

    },
    "Connectwindow\0onReadyRead\0\0on_LogInB_clicked\0"
    "on_Exit_clicked\0parse_cmd\0"
    "std::vector<std::string>\0datas_vec\0"
    "log_in_errors\0open_main_window\0hope\0"
    "request"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Connectwindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x0a /* Public */,
       3,    0,   50,    2, 0x0a /* Public */,
       4,    0,   51,    2, 0x0a /* Public */,
       5,    1,   52,    2, 0x0a /* Public */,
       8,    0,   55,    2, 0x0a /* Public */,
       9,    1,   56,    2, 0x0a /* Public */,
      11,    0,   59,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::VoidStar,   10,
    QMetaType::Void,

       0        // eod
};

void Connectwindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Connectwindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->onReadyRead(); break;
        case 1: _t->on_LogInB_clicked(); break;
        case 2: _t->on_Exit_clicked(); break;
        case 3: _t->parse_cmd((*reinterpret_cast< std::vector<std::string>(*)>(_a[1]))); break;
        case 4: _t->log_in_errors(); break;
        case 5: _t->open_main_window((*reinterpret_cast< void*(*)>(_a[1]))); break;
        case 6: _t->request(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Connectwindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_Connectwindow.data,
    qt_meta_data_Connectwindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Connectwindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Connectwindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Connectwindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Connectwindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
