/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** QtClass
*/

#ifndef QTCLASS_HPP_
#define QTCLASS_HPP_

#include "Igraphic.hpp"
#include <QtWidgets>
#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QMessageBox>
 
class QtClass : public Igraphic {
	public:
		QtClass();
		void connect_window(int ac, char** av) override;
		void GetUserInfo() override;
		~QtClass();
	protected:
	private:
	QWidget *window;
	QLabel *Title;
	QLineEdit *user_line;
	QLineEdit *pass_line;
	QPushButton *log_button;
};

#endif /* !QTCLASS_HPP_ */
