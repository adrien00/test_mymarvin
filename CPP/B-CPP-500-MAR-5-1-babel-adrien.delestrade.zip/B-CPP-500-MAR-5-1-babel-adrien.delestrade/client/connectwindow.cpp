/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** connectwindow
*/

#include "connectwindow.h"
#include "ui_connectwindow.h"

QTcpSocket _socket;

Connectwindow::Connectwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Connectwindow)
{
    ui->setupUi(this);
    _socket.connectToHost(QHostAddress("127.0.0.1"), 1234);
    connect(&_socket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    _mw = new MainWindow(this);
}

void Connectwindow::log_in_errors()
{
    QMessageBox::critical(this, "Pseudo", "Error : You either are already connected or have entered the wrong password\n");
}

void Connectwindow::open_main_window()
{
    _mw->show();
    this->hide();
    _mw->set_user_info(User_Name);
    request();
}

void Connectwindow::request()
{
    _socket.write("list_users|");
}

std::vector<std::string> Connectwindow::split(std::string strToSplit, char delimeter)
{
    std::stringstream ss(strToSplit);
    std::string item;
    std::vector<std::string> splittedStrings;
    while (std::getline(ss, item, delimeter))
    {
       splittedStrings.push_back(item);
    }
    return splittedStrings;
}

void Connectwindow::call_dispatch(std::vector<std::string> datas_vec)
{
    if (datas_vec[0] == "call" && datas_vec[1] == User_Name.toStdString())
        _mw->call_alert(datas_vec[2]);
    else if (datas_vec[0] == "okcall" && datas_vec[1] == User_Name.toStdString())
         _mw->PositiveAnswerToCall(datas_vec[2]);
    else if (datas_vec[0] == "okcall" && datas_vec[2] == User_Name.toStdString())
        _mw->PositiveAnswerToCall(datas_vec[1]);
    else if (datas_vec[0] == "kocall" && datas_vec[2] == User_Name.toStdString())
        _mw->NegativeAnswerToCall(datas_vec[1]);
}

void Connectwindow::contact_dispatch(std::vector<std::string> datas_vec)
{
    if (datas_vec[0] == "contact" && datas_vec[1] == User_Name.toStdString())
        _mw->contact_alert(datas_vec[2]);
    else if (datas_vec[0] == "kocontact" && datas_vec[2] == User_Name.toStdString())
        _mw->NegativeAnswerToContact(datas_vec[1]);
}

void Connectwindow::parse_cmd(std::vector<std::string> datas_vec)
{
    if (datas_vec[0] == "wrong_password")
        log_in_errors();
    else if(datas_vec[0] == "login" && datas_vec[1] == "ok")
        open_main_window();
    else if (datas_vec[0] == "call" || datas_vec[0] == "okcall" || datas_vec[0] == "kocall" )
       call_dispatch(datas_vec);
    else if (datas_vec[0] == "list_users")
        _mw->construct_users_list(datas_vec);
    else if (datas_vec[0] == "contact" || datas_vec[0] == "okcontact" || datas_vec[0] == "kocontact" )
        contact_dispatch(datas_vec);
    else if(datas_vec[0] == "User_disconnected")
        _mw->closeMainWindow();

}

void Connectwindow::onReadyRead()
{
    QByteArray datas = _socket.readAll();
    parse_cmd(split(datas.toStdString(), '|'));
}

Connectwindow::~Connectwindow()
{
    delete ui;
}
void Connectwindow::on_LogInB_clicked()
{
    //QString user_entry;
    User_Name = ui->user->text();
    std::string UserName = User_Name.toStdString();

    QString user_password;
    user_password = ui->password->text();
    std::string UserPassWord = user_password.toStdString();

    std::string toSend = "login|" + UserName + "|" + UserPassWord + "|";
    _socket.write(toSend.c_str(), toSend.size());
}

void Connectwindow::on_Exit_clicked()
{
    exit(0);
}
