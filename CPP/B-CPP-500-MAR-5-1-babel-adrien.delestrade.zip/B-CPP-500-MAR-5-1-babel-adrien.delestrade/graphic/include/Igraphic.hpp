/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** Igraphic
*/

#ifndef IGRAPHIC_HPP_
#define IGRAPHIC_HPP_

class Igraphic {
	public:
		virtual void connect_window(int ac, char **av) = 0;
		virtual void GetUserInfo() = 0;
		virtual ~Igraphic() = default;

	protected:
	private:
};

#endif /* !IGRAPHIC_HPP_ */
