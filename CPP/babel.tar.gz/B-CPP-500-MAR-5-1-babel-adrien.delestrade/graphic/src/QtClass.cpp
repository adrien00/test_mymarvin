/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** QtClass
*/

#include "../include/QtClass.hpp"

QtClass::QtClass()
{
}

QtClass::~QtClass()
{
}

void QtClass::GetUserInfo()
{
    QString contenu = user_line->text();
    QLineEdit check(window);
    check.setText(contenu);
}

void QtClass::connect_window (int ac, char **av)
{
	QApplication app(ac, av);
    window = new QWidget;
    window->setFixedSize(550,400);

	Title = new QLabel("Log into Babel", window);
	Title->move(150,50);
	Title->setFont(QFont("Arial",40));

    user_line = new QLineEdit(window);
	user_line->setAlignment(Qt::AlignCenter);
	user_line->setText("Username");
    user_line->move(185,150);
	user_line->setFont(QFont("Arial",20));


    pass_line = new QLineEdit(window);
	pass_line->setAlignment(Qt::AlignCenter);
	pass_line->setText("Password");
    pass_line->move(185,220);
	pass_line->setFont(QFont("Arial",20));
	//pass_line.setEchoMode(QLineEdit::Password);


    log_button = new QPushButton("Log In", window);
    log_button->setFont(QFont("Arial",30));
    log_button->move(210,300);
	log_button->setCursor(Qt::PointingHandCursor);

    QObject::connect(log_button, SIGNAL(clicked()), window, SLOT(GetUserInfo()));

    window->show();
    app.exec();
}
