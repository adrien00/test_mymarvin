/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Action
*/

#include "../include/Action.hpp"
#include "../include/Con_handler.hpp"
#include "../include/Mainserv.hpp"

Action::Action()
{
    _dataBase = new Database();
}

void Action::LoadFromDB()
{
    _dataBase->loadSaveDB();
}

void Action::saveToDB()
{
    _dataBase->saveDB();
}

void Action::createClient(std::string UserName, std::string UserID)
{
    _dataBase->setNewUser(UserName, UserID, "MERDE");
}

void Action::conectToClient(std::string userID, std::string contactID)
{

}

void Action::callClient()
{

}

std::string Action::login(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string Unsername = *it;
    it++;
    if(clientAlreadyExist(Unsername) == 0) {
        _dataBase->setNewUser(Unsername, _dataBase->Idgenerate(), *it);
        return "login|ok";
    } else if((_dataBase->getUSerPassWord(Unsername) != *it) && (clientAlreadyExist(Unsername) == 1)){
        return "wrong_password";
    } else {
        return "login|ok";
    }

    return "No password";
}

std::string Action::list_users()
{
    std::string Userlist = "list_users|";
    Userlist = Userlist + _dataBase->list_users();
    return Userlist;
}

//std::string Action::callUser(std::list<std::string> Input)
//{
//    std::list<std::string>::iterator it=Input.begin();
//    it++;
//    std::string UserContact = *it;
//    it++;
//    std::string UserName = *it;
//    for (std::list<Con_handler::pointer>::iterator it=::_listSockets.begin(); it != ::_listSockets.end(); ++it)
//        it->unique()
//    return ("Callsend");
//}

std::string Action::IfForest(std::list<std::string> Input)
{
    std::string cmd;
    std::list<std::string>::iterator it=Input.begin();
    cmd = *it;
    if(cmd == "login" || cmd == "list_users") {
        if (cmd == "login")
            return login(Input);
        else
            return list_users();
    } //if(cmd == "call")
        //return callUser(Input);
    return "Commande Inconue";
}

std::string Action::parseCmd(std::string Input)
{
    _dataBase->clearDB();
    _dataBase->loadSaveDB();

    //_dataBase->display();
    std::cout << "Input = " << Input << std::endl;
    std::list<std::string> _parser = split(Input, '|');
    std::string temp;
    //int i = 0;
    //while(Input[i] != 0) {
    //    if(Input[i] != '|') {
    //    temp = temp + Input[i];
    //    i++;
    //    } else {
    //        _parser.push_back(temp);
    //        i++;
    //        temp.clear();
    //    }
    //}
    temp = IfForest(_parser);
    _parser.clear();
    _dataBase->saveDB();
    return temp;
}

int Action::clientAlreadyExist(std::string Username)
{
    return _dataBase->UserAlreadyexist(Username);
}

Action::~Action()
{
}
