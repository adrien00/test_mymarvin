/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** User
*/

#ifndef USER_HPP_
#define USER_HPP_
#include <iostream>
#include <map>
#include <list>
#include <fstream>

class User {
    public:
        User();
        ~User();
        void setUsername(std::string);
        std::string getUsername();
        void setUserID(std::string);
        std::string getUserID();
        void setPassWord(std::string);
        std::string getPassword();
        std::string getConectionStatement();
        void addContact(std::string);
        void setConectionStatement(std::string);
        std::list<std::string> getContact();
        bool alreadyconnected();

    protected:
    private:
    std::string _userName;
    std::string _userID;
    std::string _PassWord;
    std::string _ConectionStatement;

    //listes des messages, la map contien le nom de l'interlocuteur, et la liste dans la map, les messages echangés
    std::list<std::string> _contact;
    //std::map<std::string, int> _call;
};

#endif /* !USER_HPP_ */
