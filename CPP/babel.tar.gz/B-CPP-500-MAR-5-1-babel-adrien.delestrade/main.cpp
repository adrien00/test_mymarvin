//
// EPITECH PROJECT, 2018
// babel
// File description:
//
//

#include <stdio.h>
#include <opus/opus.h>
#include <portaudio.h>
#include <QLabel>
#include <QLineEdit>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>

int main(int argc, char **argv)
{
	QApplication app(argc, argv);
    QWidget window;
    window.setFixedSize(550,400);

    QLabel Title ("Log into Babel", &window);
    Title.move(150,50);
	Title.setFont(QFont("Arial",40));

    QLineEdit user_line(&window);
	user_line.setAlignment(Qt::AlignCenter);
	user_line.setText("Username");
    user_line.move(185,150);
	user_line.setFont(QFont("Arial",20));

    QLineEdit pass_line(&window);
	pass_line.setAlignment(Qt::AlignCenter);
	pass_line.setText("Password");
    pass_line.move(185,220);
	pass_line.setFont(QFont("Arial",20));
	//pass_line.setEchoMode(QLineEdit::Password);

    QPushButton b_co("Log In", &window);
    b_co.setFont(QFont("Arial",30));
    b_co.move(210,300);
	b_co.setCursor(Qt::PointingHandCursor);

    window.show();
	app.exec();
}
	/*QApplication app (argc, argv);

	QWidget fenetre;
	fenetre.setFixedSize(550, 400);

	QPushButton bouton("Se connecter !", &fenetre);
	bouton.setCursor(Qt::PointingHandCursor);
	bouton.move(210, 330);

	fenetre.show();
	return app.exec();
}*/
