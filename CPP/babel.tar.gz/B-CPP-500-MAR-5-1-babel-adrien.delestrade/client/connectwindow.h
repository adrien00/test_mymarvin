/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** connectwindow
*/

#ifndef CONNECTWINDOW_H
#define CONNECTWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QDebug>
#include <QHostAddress>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include "mainwindow.h"

namespace Ui {
class Connectwindow;
}

class Connectwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Connectwindow(QWidget *parent = nullptr);
    ~Connectwindow();

public slots:
    void onReadyRead();
    void on_LogInB_clicked();
    void on_Exit_clicked();
    void parse_cmd(std::vector<std::string> datas_vec);
    void log_in_errors();
    void open_main_window(void *hope);
    void request();


private:
    Ui::Connectwindow *ui;
    Ui::Connectwindow *user;
    Ui::Connectwindow *password;
    QTcpSocket _socket;
    std::vector<std::string> split(std::string strToSplit, char delimeter);

};

#endif // CONNECTWINDOW_H
