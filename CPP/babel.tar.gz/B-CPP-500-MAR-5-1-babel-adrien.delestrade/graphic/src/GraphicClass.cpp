/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** GraphicClass
*/

#include "../include/GraphicClass.hpp"

GraphicClass::GraphicClass() : QtClass()
{
}

GraphicClass::~GraphicClass()
{
}