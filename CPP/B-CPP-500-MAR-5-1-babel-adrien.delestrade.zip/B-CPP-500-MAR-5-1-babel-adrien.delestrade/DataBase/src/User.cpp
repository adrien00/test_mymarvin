/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** User
*/

#include "../include/User.hpp"

User::User()
{
}

User::~User()
{
}

void User::setUsername(std::string Username)
{
    _userName = Username;
}

std::string User::getUsername()
{
    return _userName;
}

void User::setUserID(std::string UserID)
{
    _userID = UserID;
}

void User::setPassWord(std::string PassWord)
{
    _PassWord = PassWord;
}

std::string User::getPassword()
{
    return _PassWord;
}

std::string User::getUserID()
{
    return _userID;
}

std::string User::getConectionStatement()
{
    return _ConectionStatement;
}

void User::addContact(std::string contactName)
{
    _contact.push_back(contactName);
}

std::list<std::string> User::getContact()
{
    return _contact;
}

void User::setConectionStatement(std::string ConectionStatement)
{
    _ConectionStatement = ConectionStatement;
}

bool User::alreadyconnected()
{
    std::cout << "getConectionStatement :"<<getConectionStatement() << std::endl;
    if (getConectionStatement() == "connected")
        return true;
    else
        return false;
}
