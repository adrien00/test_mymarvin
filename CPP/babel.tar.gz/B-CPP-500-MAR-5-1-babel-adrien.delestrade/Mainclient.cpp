/*
** EPITECH PROJECT, 2020
** babel
** File description:
** MainClient
*/

#include "../include/Mainclient.hpp"


Mainclient::Mainclient()
{
}

Mainclient::~Mainclient()
{
}

int main(int ac, char **av) {

     Igraphic *Graph_Obj = new GraphicClass;
     std::cout << "test1" << std::endl;
     boost::asio::io_service io_service;
     std::cout << "test2" << std::endl;
//socket creation
     boost::asio::ip::tcp::socket socket(io_service);
     std::cout << "test3" << std::endl;
//connection
     socket.connect(boost::asio::ip::tcp::endpoint( boost::asio::ip::address::from_string("127.0.0.1"), 1234 ));
     std::cout << "test4" << std::endl;
// request/message from client
     const std::string msg = "I am Client\n";
     std::cout << "test5" << std::endl;
     boost::system::error_code error;
     std::cout << "test6" << std::endl;
     boost::asio::write( socket, boost::asio::buffer(msg), error );

     std::cout << "test7" << std::endl;

     if( !error ) {
        std::cout << "Client sent hello message!" << std::endl;
     }
     else {
        std::cout << "send failed: " << error.message() << std::endl;
     }
     std::cout << "test8" << std::endl;
 // getting response from server

    boost::asio::streambuf receive_buffer;
     std::cout << "test9" << std::endl;
    boost::asio::read(socket, receive_buffer, boost::asio::transfer_all(), error);
     std::cout << "test10" << std::endl;
    if ( error && error != boost::asio::error::eof ) {
        std::cout << "receive failed: " << error.message() << std::endl;
    }
    else {
        const char* data = boost::asio::buffer_cast<const char*>(receive_buffer.data());
        std::cout << data << std::endl;
    }

     std::cout << "test11" << std::endl;
    //std::string input = "OUI";
    //while(input != "QUIT"){
    //    std::cout << "Please, enter your full name: ";
    //    std::getline (std::cin,input);
    //
    //    boost::asio::write( socket, boost::asio::buffer(input), error );
    //    if( !error ) {
    //        std::cout << "Client sent hello message!" << std::endl;
    //    }
    //    else {
    //        std::cout << "send failed: " << error.message() << std::endl;
    //    }
    //}

    //Graph_Obj->connect_window(ac, av);

    return 0;
}