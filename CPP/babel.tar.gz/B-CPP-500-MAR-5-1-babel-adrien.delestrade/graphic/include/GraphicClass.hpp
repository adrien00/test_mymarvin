/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** GraphicClass
*/

#ifndef GRAPHICCLASS_HPP_
#define GRAPHICCLASS_HPP_
#include "QtClass.hpp"

class GraphicClass : public QtClass {
	public:
		GraphicClass();
		~GraphicClass();

	protected:
	private:
};

#endif /* !GRAPHICCLASS_HPP_ */
