/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** IconHandler
*/

#ifndef ICONHANDLER_HPP_
#define ICONHANDLER_HPP_

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/enable_shared_from_this.hpp>

class IconHandler {
    public:
		virtual void startRead() = 0;
		virtual void write(std::string str) = 0;
		virtual void handle_read(const boost::system::error_code& err, size_t bytes_transferred) = 0;
		virtual void handle_write(const boost::system::error_code& err, size_t bytes_transferred) = 0;
        virtual std::string getData() = 0;
        virtual bool isConnected() = 0;
        virtual ~IconHandler() = default;

    protected:
    private:
};

#endif /* !ICONHANDLER_HPP_ */
