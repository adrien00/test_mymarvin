/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Action
*/

#ifndef ACTION_HPP_
#define ACTION_HPP_

#include "Iactions.hpp"

class Action : public Iactions{
    public:
        Action();
        void createClient(std::string UserName, std::string UserID) override;
        int clientAlreadyExist(std::string Username) override;
        void conectToClient(std::string userID, std::string contactI) override;
        void callClient() override;
        ~Action() override;
        void saveToDB() override;
        void LoadFromDB() override;
        std::string parseCmd(std::string Input) override;
        std::string IfForest(std::list<std::string>) override;
        std::string login(std::list<std::string>) override;
        std::string callUser(std::list<std::string> Input) override;
        std::string list_users() override;
        std::string okCall(std::list<std::string> Input) override;
        std::string koCall(std::list<std::string> Input) override;
        std::string koContact(std::list<std::string> Input) override;
        std::string okContact(std::list<std::string> Input) override;
        std::string Contact(std::list<std::string> Input) override;
        std::string client_disconnected(std::list<std::string> Input) override;

    protected:
    private:
    IDatabase *_dataBase;
};

#endif /* !ACTION_HPP_ */
