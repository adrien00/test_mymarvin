/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QLabel *ContactL;
    QListWidget *listWidget;
    QLabel *StatusUserL;
    QLabel *UserNameL;
    QPushButton *NotifB;
    QPushButton *ContactGestion;
    QPushButton *Exit;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(795, 538);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        scrollArea = new QScrollArea(centralwidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(0, 110, 231, 391));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 229, 389));
        ContactL = new QLabel(scrollAreaWidgetContents);
        ContactL->setObjectName(QString::fromUtf8("ContactL"));
        ContactL->setGeometry(QRect(10, 10, 121, 21));
        QFont font;
        font.setPointSize(19);
        ContactL->setFont(font);
        scrollArea->setWidget(scrollAreaWidgetContents);
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(0, 0, 231, 111));
        StatusUserL = new QLabel(centralwidget);
        StatusUserL->setObjectName(QString::fromUtf8("StatusUserL"));
        StatusUserL->setGeometry(QRect(10, 60, 121, 21));
        QFont font1;
        font1.setPointSize(14);
        StatusUserL->setFont(font1);
        UserNameL = new QLabel(centralwidget);
        UserNameL->setObjectName(QString::fromUtf8("UserNameL"));
        UserNameL->setGeometry(QRect(10, 20, 121, 21));
        UserNameL->setFont(font1);
        NotifB = new QPushButton(centralwidget);
        NotifB->setObjectName(QString::fromUtf8("NotifB"));
        NotifB->setGeometry(QRect(682, 0, 111, 31));
        QFont font2;
        font2.setPointSize(12);
        NotifB->setFont(font2);
        ContactGestion = new QPushButton(centralwidget);
        ContactGestion->setObjectName(QString::fromUtf8("ContactGestion"));
        ContactGestion->setGeometry(QRect(0, 500, 141, 31));
        QFont font3;
        font3.setPointSize(9);
        ContactGestion->setFont(font3);
        Exit = new QPushButton(centralwidget);
        Exit->setObjectName(QString::fromUtf8("Exit"));
        Exit->setGeometry(QRect(700, 490, 51, 31));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        ContactL->setText(QCoreApplication::translate("MainWindow", "Contacts :", nullptr));
        StatusUserL->setText(QCoreApplication::translate("MainWindow", "Statut : en ligne", nullptr));
        UserNameL->setText(QCoreApplication::translate("MainWindow", "UserName", nullptr));
        NotifB->setText(QCoreApplication::translate("MainWindow", "Notifications", nullptr));
        ContactGestion->setText(QCoreApplication::translate("MainWindow", "Gestion de Contacts", nullptr));
        Exit->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
