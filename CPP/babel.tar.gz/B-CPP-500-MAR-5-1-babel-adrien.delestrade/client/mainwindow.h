#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QTcpSocket>
#include <QDebug>
#include <iostream>
#include "connectwindow.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    void call_alert(std::string username);
    void construct_users_list(std::vector<std::string> datas_vec);
    ~MainWindow();


private slots:

    void on_NotifB_clicked();

    void on_ContactGestion_clicked();

    void on_Exit_clicked();

private:
    Ui::MainWindow *ui;
    QList<QString> QList_users;


};

#endif // MAINWINDOW_H
