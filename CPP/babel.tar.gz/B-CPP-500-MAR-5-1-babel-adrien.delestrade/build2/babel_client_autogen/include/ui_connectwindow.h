/********************************************************************************
** Form generated from reading UI file 'connectwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNECTWINDOW_H
#define UI_CONNECTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Connectwindow
{
public:
    QPushButton *LogInB;
    QLabel *label;
    QLineEdit *user;
    QLineEdit *password;
    QPushButton *Exit;

    void setupUi(QWidget *Connectwindow)
    {
        if (Connectwindow->objectName().isEmpty())
            Connectwindow->setObjectName(QString::fromUtf8("Connectwindow"));
        Connectwindow->resize(640, 480);
        LogInB = new QPushButton(Connectwindow);
        LogInB->setObjectName(QString::fromUtf8("LogInB"));
        LogInB->setGeometry(QRect(260, 330, 121, 41));
        LogInB->setCursor(QCursor(Qt::OpenHandCursor));
        label = new QLabel(Connectwindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 40, 211, 81));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(35);
        font.setBold(false);
        font.setWeight(50);
        font.setKerning(true);
        label->setFont(font);
        label->setTextFormat(Qt::AutoText);
        user = new QLineEdit(Connectwindow);
        user->setObjectName(QString::fromUtf8("user"));
        user->setGeometry(QRect(220, 160, 201, 51));
        user->setClearButtonEnabled(false);
        password = new QLineEdit(Connectwindow);
        password->setObjectName(QString::fromUtf8("password"));
        password->setGeometry(QRect(220, 230, 201, 51));
        password->setEchoMode(QLineEdit::Password);
        password->setClearButtonEnabled(false);
        Exit = new QPushButton(Connectwindow);
        Exit->setObjectName(QString::fromUtf8("Exit"));
        Exit->setGeometry(QRect(260, 380, 121, 41));
        Exit->setCursor(QCursor(Qt::OpenHandCursor));

        retranslateUi(Connectwindow);

        QMetaObject::connectSlotsByName(Connectwindow);
    } // setupUi

    void retranslateUi(QWidget *Connectwindow)
    {
        Connectwindow->setWindowTitle(QCoreApplication::translate("Connectwindow", "Babel", nullptr));
        LogInB->setText(QCoreApplication::translate("Connectwindow", "Log in", nullptr));
        label->setText(QCoreApplication::translate("Connectwindow", "Log into Babel", nullptr));
        user->setText(QString());
        user->setPlaceholderText(QCoreApplication::translate("Connectwindow", "USER", nullptr));
        password->setText(QString());
        password->setPlaceholderText(QCoreApplication::translate("Connectwindow", "PASSWORD", nullptr));
        Exit->setText(QCoreApplication::translate("Connectwindow", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Connectwindow: public Ui_Connectwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNECTWINDOW_H
