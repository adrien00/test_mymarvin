/*
** EPITECH PROJECT, 2020
** babel
** File description:
** Mainserv
*/

#include "../include/Mainserv.hpp"

Mainserv::Mainserv(boost::asio::io_service &io_service):
    io_service_(io_service),
    acceptor_(io_service_, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), 1234)),
    thread_(),
    worker_()
{
    _actionServ = new Action();
    worker_ = new boost::asio::io_service::work(io_service_);
    thread_ = boost::thread(&Mainserv::thread_function, this);
    start_accept();
}

Mainserv::~Mainserv()
{
    delete worker_;
    thread_.join();
}

void Mainserv::start_accept()
{
    // socket
    Con_handler::pointer connection(new Con_handler(io_service_));

    //asynchronous accept operation and wait for a new connection.
    acceptor_.async_accept(
        connection->socket(),
        boost::bind(
            &Mainserv::handle_accept,
            this,
            connection,
            boost::asio::placeholders::error)
    );
}

void Mainserv::handle_accept(Con_handler::pointer connection, const boost::system::error_code& err)
{
    if (!err) {
        connection->startRead();
        connection->write("Hello from server");
        std::cout << "client connected" << std::endl;
        _socket.push_back(connection);
    }
    start_accept();
}

void Mainserv::sendToAll(std::string msg)
{
        for(auto const &it : _socket) {
            if(it->isConnected() == true)
                it->write(msg);
        }

}

void Mainserv::readclient(void)
{
    for(auto const &it : _socket) {
        auto data  = it->getData();
        if (data[0] != 0) {
            std::cout << "OUIII\n";
            auto toSend = _actionServ->parseCmd(data);
            std::list<std::string> _cmd = split(toSend, '|');
            std::list<std::string>::iterator qt=_cmd.begin();
            std::cout << "DATA =  " << data << std::endl;
            if (*qt == "call" || *qt == "contact" || *qt == "okcall" || *qt == "okcontact" || *qt == "kocall" || *qt == "kocontact")
                sendToAll(toSend);
            else {
                it->write(toSend);
            }
        }
    }
}

void Mainserv::loop(void)
{
    while (true) {
        //std::cout << "je peux avoir acces a la liste de sockets ici" << std::endl;
        readclient();

    }
}

void Mainserv::thread_function(void)
{
    io_service_.run();
}

int main(int argc, char *argv[])
{
  try
    {
      boost::asio::io_service io_service;
      Mainserv server(io_service);
      server.loop();
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    }
  return 0;
}