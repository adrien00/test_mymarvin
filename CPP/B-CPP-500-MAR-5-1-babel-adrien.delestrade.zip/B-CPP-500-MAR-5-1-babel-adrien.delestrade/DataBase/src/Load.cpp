/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Load
*/

#include "../include/Database.hpp"



std::list<std::string> split(std::string strToSplit, char delimeter)
{
    std::stringstream ss(strToSplit);
    std::string item;
    std::list<std::string> splittedStrings;
    while (std::getline(ss, item, delimeter))
    {
       splittedStrings.push_back(item);
    }
    return splittedStrings;
}

void Database::loadUser(std::string save)
{
    //std::cout << "SAVE = " << save << std::endl;
    if((int)save.find("|") != -1) {
        std::list<std::string> User =split(save, '|');

        std::list<std::string>::iterator it=User.begin();
        std::string userID = *it;
        it++;
        std::string userName = *it;
        it++;
        std::string passWord = *it;
        setNewUser(userName, userID, passWord);
    }

}

void Database::loadState(std::string save, std::string Username)
{
    //std::cout << "save = " << save <<std::endl;
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it) {
        if(it->second->getUsername() == Username) {
            if(save == "connected")
                it->second->setConectionStatement("connected");
            else if (save == "disconnected")
                it->second->setConectionStatement("disconnected");
        }
    }
}

void Database::loadContact(std::string save, std::string Username)
{
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it) {
        if(it->second->getUsername() == Username) {
            it->second->addContact(save);
        }
    }
}

void Database::parser(std::list<std::string> Save)
{

    std::list<std::string>::iterator it=Save.begin();
    std::string UserID;
    std::string Unsername;
    while(it != Save.end() && *it != "#ENDSAVE#") {
        if(*it == "#User#") {
            std::cout << "User\n";
            it++;
            while (*it != "#state#" && *it != "#ENDSAVE#") {
                if((int)it->find("|") != -1) {
                    std::list<std::string> User =split(*it, '|');
                    std::list<std::string>::iterator qt=User.begin();
                    std::string userID = *qt;
                    qt++;
                    std::string userName = *qt;
                    Unsername = userName;
                    qt++;
                    std::string passWord = *qt;
                    setNewUser(userName, userID, passWord);
                    
                }
                it++;
            }
        } if (*it == "#state#") {
            it++;
            while(*it != "#User#" && *it != "#ENDSAVE#" && *it != "#Contact#") {
                std::cout << "it = " << *it << std::endl;
                loadState(*it, Unsername);
                //Unsername.clear();
                it++;
            }
        } if (*it == "#Contact#") {
            it++;
            while(*it != "#User#" && *it != "#ENDSAVE#") {
                loadContact(*it, Unsername);
                Unsername.clear();
                it++;
            }
        }
    }
}

void Database::clearDB()
{
    _users.clear();
}

void Database::loadSaveDB()
{
    std::list<std::string> Save;
    std::fstream Load ("../Database/src/save.txt", std::ifstream::in);
    if(Load.is_open()) {
        std::string tp;
        std::string LoadFromSave;
        while(getline(Load, tp)){

            Save.push_back(tp);
        //LoadFromSave = LoadFromSave + tp;
        //LoadFromSave += '\n';
        }

        parser(Save);
        std::cout << "T'es con\n";
    } else
        std::cout << "It's not Open" << std::endl;
    Load.close();

}