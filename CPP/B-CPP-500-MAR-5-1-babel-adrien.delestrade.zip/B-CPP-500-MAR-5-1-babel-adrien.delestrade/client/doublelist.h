#ifndef DOUBLELIST_H
#define DOUBLELIST_H

#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QObject>
#include <QMainWindow>

namespace Ui {
class DoubleList;
}

class DoubleList : public QMainWindow
{
    Q_OBJECT

public:
    explicit DoubleList(QMainWindow *parent = nullptr);
    void addAvailableItems(const QStringList &items, QString user_name);
    void init();
    void connections();
    QStringList seletedItems();
     ~DoubleList();
    QStringList ContactsToAdd;
    int OkBtnCheck;


private:
    void setStatusButton();
    QString _user_name;
    Ui::DoubleList *ui;
    Ui::DoubleList *mInput;
    Ui::DoubleList *mOutput;

    Ui::DoubleList *mButtonToAvailable;
    Ui::DoubleList *mButtonToSelected;

    Ui::DoubleList *mBtnMoveToAvailable;
    Ui::DoubleList *mBtnMoveToSelected;

    Ui::DoubleList *mBtnUp;
    Ui::DoubleList *mBtnDown;

    Ui::DoubleList *OkBtn;
};

#endif // DOUBLELIST_H
