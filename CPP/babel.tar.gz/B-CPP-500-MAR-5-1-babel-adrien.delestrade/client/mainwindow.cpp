#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "doublelist.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_NotifB_clicked()
{

}

void MainWindow::call_alert(std::string username)
{
    //std::cout << "call_alert" << std::endl;
    int answer = QMessageBox::question(this, "Incoming Call", QString::fromStdString(username) + " is calling\nWould you like to accept the call ?", QMessageBox::Yes | QMessageBox::No);
    if (answer == QMessageBox::No)
        this->close();
}

void MainWindow::construct_users_list(std::vector<std::string> datas_vec)
{
    for(int i = 1; i < datas_vec.size() ; i++) {
        //qDebug() << QString::fromStdString(datas_vec[i]);
        QList_users << QString::fromStdString(datas_vec[i]);
        //QList_users[i] = QString::fromStdString(datas_vec[i]);
        // bon, c'est quoi l'hi
    }
        qDebug() << QList_users;

}

void MainWindow::on_ContactGestion_clicked()
{
    DoubleList *doublelist = new DoubleList(this);
    doublelist->show();
    doublelist->addAvailableItems(QList_users);
    //for(int i = 0; i < QList_users.size() ; i++)
    std::cout << "LISTE:" << std::endl;
    qDebug() << QList_users;

}

void MainWindow::on_Exit_clicked()
{
    exit(0);
}
