#include "doublelist.h"
#include "ui_doublelist.h"

DoubleList::DoubleList(QMainWindow *parent) :
    QMainWindow(parent),
    ui(new Ui::DoubleList)
{
    ui->setupUi(this);
    init();
    connections();
}

DoubleList::~DoubleList()
{
    delete ui;
}

 void DoubleList::addAvailableItems(const QStringList &items){
        ui->mInput->addItems(items);
}

QStringList DoubleList::seletedItems() {
    QStringList selected;
    for(int i=0; i < ui->mOutput->count(); i++)
        selected << ui->mOutput->item(i)->text();
        return selected;
}

void DoubleList::init() {
        setStatusButton();
}

void DoubleList::connections() {
    connect(ui->mOutput, &QListWidget::itemSelectionChanged, this, &DoubleList::setStatusButton);
    connect(ui->mInput, &QListWidget::itemSelectionChanged, this, &DoubleList::setStatusButton);
    connect(ui->mBtnMoveToAvailable, &QPushButton::clicked, [=](){
       ui->mOutput->addItem(ui->mInput->takeItem(ui->mInput->currentRow()));
    });

    connect(ui->mBtnMoveToSelected, &QPushButton::clicked, [=](){
       ui->mInput->addItem(ui->mOutput->takeItem(ui->mOutput->currentRow()));
    });

    connect(ui->mButtonToAvailable, &QPushButton::clicked, [=](){
        while (ui->mOutput->count()>0) {
             ui->mInput->addItem(ui->mOutput->takeItem(0));
        }
    });

    connect(ui->mButtonToSelected, &QPushButton::clicked, [=](){
        while (ui->mInput->count()>0) {
             ui->mOutput->addItem(ui->mInput->takeItem(0));
        }
    });

    connect(ui->mBtnUp, &QPushButton::clicked, [=](){
        int row = ui->mOutput->currentRow();
        QListWidgetItem *currentItem = ui->mOutput->takeItem(row);
        ui->mOutput->insertItem(row-1, currentItem);
        ui->mOutput->setCurrentRow(row-1);
    });

    connect(ui->mBtnDown, &QPushButton::clicked, [=](){
        int row = ui->mOutput->currentRow();
        QListWidgetItem *currentItem = ui->mOutput->takeItem(row);
        ui->mOutput->insertItem(row+1, currentItem);
        ui->mOutput->setCurrentRow(row+1);
    });

    connect(ui->OkBtn, &QPushButton::clicked, [=](){
        ContactsToAdd = seletedItems();
        this->close();
    });
}

void DoubleList::setStatusButton() {
       ui->mBtnUp->setDisabled(ui->mOutput->selectedItems().isEmpty() || ui->mOutput->currentRow() == 0);
       ui->mBtnDown->setDisabled(ui->mOutput->selectedItems().isEmpty() || ui->mOutput->currentRow() == ui->mOutput->count()-1);
       ui->mBtnMoveToAvailable->setDisabled(ui->mInput->selectedItems().isEmpty());
       ui->mBtnMoveToSelected->setDisabled(ui->mOutput->selectedItems().isEmpty());
}
