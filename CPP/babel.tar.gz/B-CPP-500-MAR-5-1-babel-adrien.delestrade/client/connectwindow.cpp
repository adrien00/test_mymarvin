/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** connectwindow
*/

#include "connectwindow.h"
#include "ui_connectwindow.h"

Connectwindow::Connectwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Connectwindow),
    _socket(this)
{
    ui->setupUi(this);
    _socket.connectToHost(QHostAddress("127.0.0.1"), 1234);
    connect(&_socket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

void Connectwindow::log_in_errors()
{
    QMessageBox::critical(this, "Pseudo", "Error : You either are already connected or have entered the wrong password\n");
}

void Connectwindow::open_main_window(void *hope)
{
    //MainWindow *mw = new MainWindow(this);
    //hope->show();
    request();
}

void Connectwindow::request()
{
    _socket.write("list_users|");
}

std::vector<std::string> Connectwindow::split(std::string strToSplit, char delimeter)
{
    std::stringstream ss(strToSplit);
    std::string item;
    std::vector<std::string> splittedStrings;
    while (std::getline(ss, item, delimeter))
    {
       splittedStrings.push_back(item);
    }
    return splittedStrings;
}

void Connectwindow::parse_cmd(std::vector<std::string> datas_vec)
{
    MainWindow *mw = new MainWindow(this);//est appelé à chaque fois qu'on reçoit un message DAH
    if (datas_vec[0] == "wrong_password")
        log_in_errors();
    /*else if(datas_vec[0] == "login" && datas_vec[1] == "ok")
        open_main_window();*/
    else if (/*datas_vec[0] == "call"*/datas_vec[0] == "login" && datas_vec[1] == "ok") {
       open_main_window(mw);
        /*mw->show();
        request();*/
       /*mw.call_alert(datas_vec[1]);*/
    } else if (datas_vec[0] == "list_users")
        mw->construct_users_list(datas_vec);

}

void Connectwindow::onReadyRead()
{
    QByteArray datas = _socket.readAll();
    qDebug() << datas;
    std::cout << "RECU" << datas.toStdString() << std::endl;
    parse_cmd(split(datas.toStdString(), '|'));
}

Connectwindow::~Connectwindow()
{
    delete ui;
}
void Connectwindow::on_LogInB_clicked()
{
    QString user_entry;
    user_entry = ui->user->text();
    std::string ex_user = user_entry.toStdString();

    QString user_password;
    user_password = ui->password->text();
    std::string ex_pass = user_password.toStdString();

    std::string toSend = "login|" + ex_user + "|" + ex_pass + "|";
    _socket.write(toSend.c_str(), toSend.size());

    //MainWindow *mw = new MainWindow(this);
    //mw->show();

}

void Connectwindow::on_Exit_clicked()
{
    exit(0);
}
