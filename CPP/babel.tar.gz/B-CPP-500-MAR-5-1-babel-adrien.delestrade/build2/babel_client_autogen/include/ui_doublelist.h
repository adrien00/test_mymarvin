/********************************************************************************
** Form generated from reading UI file 'doublelist.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DOUBLELIST_H
#define UI_DOUBLELIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DoubleList
{
public:
    QListWidget *mInput;
    QListWidget *mOutput;
    QPushButton *mButtonToSelected;
    QPushButton *mBtnMoveToAvailable;
    QPushButton *mBtnMoveToSelected;
    QPushButton *mButtonToAvailable;
    QPushButton *mBtnUp;
    QPushButton *mBtnDown;
    QPushButton *OkBtn;

    void setupUi(QWidget *DoubleList)
    {
        if (DoubleList->objectName().isEmpty())
            DoubleList->setObjectName(QString::fromUtf8("DoubleList"));
        DoubleList->resize(739, 546);
        mInput = new QListWidget(DoubleList);
        mInput->setObjectName(QString::fromUtf8("mInput"));
        mInput->setGeometry(QRect(10, 80, 281, 341));
        mOutput = new QListWidget(DoubleList);
        mOutput->setObjectName(QString::fromUtf8("mOutput"));
        mOutput->setGeometry(QRect(340, 80, 271, 341));
        mButtonToSelected = new QPushButton(DoubleList);
        mButtonToSelected->setObjectName(QString::fromUtf8("mButtonToSelected"));
        mButtonToSelected->setGeometry(QRect(300, 160, 31, 31));
        mBtnMoveToAvailable = new QPushButton(DoubleList);
        mBtnMoveToAvailable->setObjectName(QString::fromUtf8("mBtnMoveToAvailable"));
        mBtnMoveToAvailable->setGeometry(QRect(300, 200, 31, 31));
        mBtnMoveToSelected = new QPushButton(DoubleList);
        mBtnMoveToSelected->setObjectName(QString::fromUtf8("mBtnMoveToSelected"));
        mBtnMoveToSelected->setGeometry(QRect(300, 240, 31, 31));
        mButtonToAvailable = new QPushButton(DoubleList);
        mButtonToAvailable->setObjectName(QString::fromUtf8("mButtonToAvailable"));
        mButtonToAvailable->setGeometry(QRect(300, 280, 31, 31));
        mBtnUp = new QPushButton(DoubleList);
        mBtnUp->setObjectName(QString::fromUtf8("mBtnUp"));
        mBtnUp->setGeometry(QRect(640, 200, 51, 31));
        mBtnDown = new QPushButton(DoubleList);
        mBtnDown->setObjectName(QString::fromUtf8("mBtnDown"));
        mBtnDown->setGeometry(QRect(640, 240, 51, 31));
        OkBtn = new QPushButton(DoubleList);
        OkBtn->setObjectName(QString::fromUtf8("OkBtn"));
        OkBtn->setGeometry(QRect(672, 470, 51, 31));

        retranslateUi(DoubleList);

        QMetaObject::connectSlotsByName(DoubleList);
    } // setupUi

    void retranslateUi(QWidget *DoubleList)
    {
        DoubleList->setWindowTitle(QCoreApplication::translate("DoubleList", "Form", nullptr));
        mButtonToSelected->setText(QCoreApplication::translate("DoubleList", ">>", nullptr));
        mBtnMoveToAvailable->setText(QCoreApplication::translate("DoubleList", ">", nullptr));
        mBtnMoveToSelected->setText(QCoreApplication::translate("DoubleList", "<", nullptr));
        mButtonToAvailable->setText(QCoreApplication::translate("DoubleList", "<<", nullptr));
        mBtnUp->setText(QCoreApplication::translate("DoubleList", "Up", nullptr));
        mBtnDown->setText(QCoreApplication::translate("DoubleList", "Down", nullptr));
        OkBtn->setText(QCoreApplication::translate("DoubleList", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DoubleList: public Ui_DoubleList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DOUBLELIST_H
