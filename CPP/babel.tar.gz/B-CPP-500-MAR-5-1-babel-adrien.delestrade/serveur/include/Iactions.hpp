/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Iactions
*/

#ifndef IACTIONS_HPP_
#define IACTIONS_HPP_
#include "../../DataBase/include/Database.hpp"

class Iactions {
    public:
        virtual void createClient(std::string, std::string) = 0;
        virtual int clientAlreadyExist(std::string Username) = 0;
        virtual void conectToClient(std::string, std::string) = 0;
        virtual void callClient() = 0;
        virtual void saveToDB() = 0;
        virtual void LoadFromDB() = 0;
        virtual std::string parseCmd(std::string Input) = 0;
        virtual std::string login(std::list<std::string>) = 0;
        virtual std::string IfForest(std::list<std::string>) = 0;
        virtual std::string list_users() = 0;
        virtual ~Iactions() = default;

    protected:
    private:
};

#endif /* !IACTIONS_HPP_ */
