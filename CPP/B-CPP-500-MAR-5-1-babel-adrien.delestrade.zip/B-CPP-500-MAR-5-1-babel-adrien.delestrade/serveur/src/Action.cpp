/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Action
*/

#include "../include/Action.hpp"
#include "../include/Con_handler.hpp"
#include "../include/Mainserv.hpp"

Action::Action()
{
    _dataBase = new Database();
}

void Action::LoadFromDB()
{
    _dataBase->loadSaveDB();
}

void Action::saveToDB()
{
    _dataBase->saveDB();
}

void Action::createClient(std::string UserName, std::string UserID)
{
    _dataBase->setNewUser(UserName, UserID, "MERDE");
}

void Action::conectToClient(std::string userID, std::string contactID)
{

}

void Action::callClient()
{

}

std::string Action::login(std::list<std::string> Input)
{
    std::cout << "ICIIII\n";
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string Unsername = *it;
    it++;
    if(clientAlreadyExist(Unsername) == 0) {
        _dataBase->setNewUser(Unsername, _dataBase->Idgenerate(), *it);
        _dataBase->setState(Unsername, "connected");
        return "login|ok";
    } else if((_dataBase->getUSerPassWord(Unsername) != *it) && (clientAlreadyExist(Unsername) == 1)){
        return "wrong_password";
    } else if(_dataBase->alreadyconnected(Unsername) == true) {
        return "wrong_password";
    } else {
        _dataBase->setState(Unsername, "connected");
        return "login|ok";
    }
    return "No password";
}

std::string Action::list_users()
{
    std::string Userlist = "list_users|";
    Userlist = Userlist + _dataBase->list_users();
    return Userlist;
}

std::string Action::callUser(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "call|" + UserContact +  '|' + UserName;
    return _return;
}

std::string Action::okCall(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "okcall|" + UserContact + '|' + UserName;
    return _return;
}

std::string Action::koCall(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "kocall|" + UserContact + '|' + UserName;
    return _return;
}
std::string Action::koContact(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "kocontact|" + UserContact + '|' + UserName;
    return _return;
}
std::string Action::okContact(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "okcontact|" + UserContact +  '|' +UserName;
    _dataBase->addContact(UserName, UserContact);
    return _return;
}

std::string Action::Contact(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    std::string UserContact = *it;
    it++;
    std::string UserName = *it;
    std::string _return = "contact|" + UserContact + '|' + UserName;
    return _return;

}

std::string Action::client_disconnected(std::list<std::string> Input)
{
    std::list<std::string>::iterator it=Input.begin();
    it++;
    return _dataBase->UserDisconect(*it);
}

std::string Action::IfForest(std::list<std::string> Input)
{
    std::string cmd;
    std::list<std::string>::iterator it=Input.begin();
    cmd = *it;
    std::cout << "cmd = "<< cmd << std::endl;
    if(cmd == "login" || cmd == "list_users") {
        if (cmd == "login")
            return login(Input);
        else
            return list_users();
    } if(cmd == "call" || cmd == "okcall" || cmd == "kocall") {
        if (cmd == "call")
            return callUser(Input);
        else if (cmd == "okcall")
            return okCall(Input);
        else
            return koCall(Input);
    }   if(cmd == "contact" || cmd == "okcontact" || cmd == "kocontact") {
        if (cmd == "contact")
            return Contact(Input);
        else if (cmd == "okcontact")
            return okContact(Input);
        else
            return koContact(Input);
    } if (cmd == "client_disconnected")
        return client_disconnected(Input);
    return "Commande Inconue";
}

std::string Action::parseCmd(std::string Input)
{

    _dataBase->clearDB();
    _dataBase->loadSaveDB();

    std::cout<< "Input = " << Input << std::endl;
    std::list<std::string> _parser = split(Input, '|');
    std::string temp;
    temp = IfForest(_parser);
    _parser.clear();
    _dataBase->saveDB();
    return temp;
}

int Action::clientAlreadyExist(std::string Username)
{
    return _dataBase->UserAlreadyexist(Username);
}

Action::~Action()
{
}
