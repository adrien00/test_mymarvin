#include "connectwindow.h"
#include "mainwindow.h"

#include <QApplication>

void login()
{

}

int main(int ac, char ** av)
{
    QApplication a(ac, av);
    Connectwindow connectWindow;
    connectWindow.show();



    return a.exec();

}