/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Load
*/

#include "../include/Database.hpp"



std::list<std::string> split(std::string strToSplit, char delimeter)
{
    std::stringstream ss(strToSplit);
    std::string item;
    std::list<std::string> splittedStrings;
    while (std::getline(ss, item, delimeter))
    {
       splittedStrings.push_back(item);
    }
    return splittedStrings;
}

void Database::loadUser(std::string save)
{
    //std::cout << "SAVE = " << save << std::endl;
    if((int)save.find("|") != -1) {
        std::list<std::string> User =split(save, '|');

        std::list<std::string>::iterator it=User.begin();
        std::string userID = *it;
        it++;
        std::string userName = *it;
        it++;
        std::string passWord = *it;
        setNewUser(userName, userID, passWord);
    }

}

void Database::loadState(std::string save)
{
    std::map<std::string, User*>::iterator it=_users.end();
    if((int)save.find("connected") != -1)
        it->second->setConectionStatement("connected");
    else if ((int)save.find("disconnected") != -1)
        it->second->setConectionStatement("disconected");
}

void Database::parser(std::list<std::string> Save)
{

    std::list<std::string>::iterator it=Save.begin();
    std::string UserID;
    while(it != Save.end() && *it != "#ENDSAVE#") {
        if(*it == "#User#") {
            it++;
            while (*it != "#state#" && *it != "#ENDSAVE#") {
                loadUser(*it);
                it++;
            }
        } if (*it == "#state#") {
            it++;
            while(*it != "#User#" && *it != "#ENDSAVE#" && *it != "#Contact#") {
                loadState( *it);
                //std::cout << *it <<std::endl;
                it++;
            }
            //std::cout << "-----------------------fin d'affichage des Contatc  it = " << *it << std::endl;

            //std::cout << "-----------------------fin d'affichage des MSG  it = " << *it << std::endl;
        }
    }
}

void Database::clearDB()
{
    _users.clear();
}

void Database::loadSaveDB()
{
    //std::cout<< "TA MERE\n";
    std::list<std::string> Save;
    std::fstream Load ("../Database/src/save.txt", std::ifstream::in);
    if(Load.is_open()) {
        std::string tp;
        std::string LoadFromSave;
        while(getline(Load, tp)){
            Save.push_back(tp);
        //LoadFromSave = LoadFromSave + tp;
        //LoadFromSave += '\n';
        }
        parser(Save);
    } else
        std::cout << "It's not Open" << std::endl;
    Load.close();

}