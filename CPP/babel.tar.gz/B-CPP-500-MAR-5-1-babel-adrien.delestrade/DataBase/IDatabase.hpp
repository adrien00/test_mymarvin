/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** IDatabse
*/

#ifndef IDATABSE_HPP_
#define IDATABSE_HPP_

#include <iostream>
#include <map>
#include <list>
#include <fstream>
#include "include/User.hpp"
#include <string>
#include <sstream>

class IDatabase {
    public:
        virtual ~IDatabase() = default;
        std::string takeUserID(std::string);
        virtual int setNewUser(std::string UserName, std::string UserID, std::string Password) = 0;
        virtual void saveDB() = 0;
        virtual void loadSaveDB() = 0;
        virtual void loadState(std::string save) = 0;
        virtual void parser(std::list<std::string> Save) = 0;
        virtual int UserAlreadyexist(std::string) = 0;
        virtual std::string Idgenerate() = 0;
        virtual std::string getUSerPassWord(std::string UserID) = 0;
        virtual void loadUser(std::string save) = 0;
        virtual void clearDB() = 0;
        virtual std::string list_users() = 0;
        virtual void SaveState(User *user, std::ofstream &myfile) = 0;
        virtual std::string UserDisconect(std::string Username) = 0;
    protected:
    private:
};

#endif /* !IDATABSE_HPP_ */
