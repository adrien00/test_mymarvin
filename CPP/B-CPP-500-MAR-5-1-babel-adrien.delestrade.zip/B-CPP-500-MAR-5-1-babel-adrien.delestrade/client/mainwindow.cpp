#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <cstdlib>
#include <unistd.h>


extern QTcpSocket _socket;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    doublelist = new DoubleList(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::set_user_info(QString username)
{
    ui->UserNameL->setText(username);
    user_name = username;
}

void MainWindow::call_alert(std::string caller)
{
    int answer = QMessageBox::question(this, "Incoming Call", QString::fromStdString(caller) + " is calling\nWould you like to accept the call ?", QMessageBox::Yes | QMessageBox::No);
    if (answer == QMessageBox::No) {
        std::string toSend = "kocall|" + user_name.toStdString()+ "|" + caller+  "|";
        _socket.write(toSend.c_str(), toSend.size());
    }
    if (answer == QMessageBox::Yes) {
        //std::cout << "ici ok call " << std::endl;
        std::string toSend = "okcall|" + user_name.toStdString()+ "|" + caller+  "|";
        _socket.write(toSend.c_str(), toSend.size());
    }

}

void MainWindow::contact_alert(std::string asker)
{
    int answer = QMessageBox::question(this, "Incoming Contact" ,QString::fromStdString(asker) + " wants to add you in his/her contacts\nWould you like to accept ?", QMessageBox::Yes | QMessageBox::No);
    if (answer == QMessageBox::No) {
        std::string toSend = "kocontact|" + user_name.toStdString()+ "|" + asker +  "|";
        _socket.write(toSend.c_str(), toSend.size());
    }
    if (answer == QMessageBox::Yes) {
        std::string toSend = "okcontact|" + user_name.toStdString()+ "|" + asker +  "|";
        _socket.write(toSend.c_str(), toSend.size());
    }
}

void MainWindow::construct_users_list(std::vector<std::string> datas_vec)
{
    for(int i = 1; i < datas_vec.size() ; i++)
        QList_users << QString::fromStdString(datas_vec[i]);
}

void MainWindow::on_ContactGestion_clicked()
{
    static int tempo = 0;
    doublelist->show();
    if (tempo == 0) {
        doublelist->addAvailableItems(QList_users, user_name);
        tempo += 1;
    }
}

void MainWindow::closeMainWindow()
{
    exit(0);
}

void MainWindow::on_Exit_clicked()
{
    std::string cmd = "client_disconnected|" + user_name.toStdString();
    _socket.write(cmd.c_str(), cmd.size());
    //exit(0);
}

void MainWindow::on_CallBtn_clicked()
{
    bool ok = false;
    QString ToCall = QInputDialog::getText(this, "Call", "Who do you want to call ?", QLineEdit::Normal, QString(), &ok);
    std::string toSend = "call|" + ToCall.toStdString() + '|' + user_name.toStdString() +  '|';
    _socket.write(toSend.c_str(), toSend.size());
}

void MainWindow::PositiveAnswerToCall(std::string caller)
{
    QMessageBox::information(this, "Call", "You're on a call with " + QString::fromStdString(caller));
}

void MainWindow::NegativeAnswerToCall(std::string caller)
{
    QMessageBox::critical(this, "Call", QString::fromStdString(caller) + " refused your call...\nSnif!");
}

void MainWindow::NegativeAnswerToContact(std::string name_contact)
{
    qDebug() << doublelist->ContactsToAdd;
    for (int y = 0; y < doublelist->ContactsToAdd.size(); ++y) {
        if (doublelist->ContactsToAdd[y].toStdString() == name_contact) {
            doublelist->ContactsToAdd.removeAt(y);
        }
    }
    qDebug() << doublelist->ContactsToAdd;
}

void MainWindow::on_UpdateContactBtn_clicked()
{
    if (doublelist->OkBtnCheck == 1) {
        if (ui->UserContactList->count() != 0)
            ui->UserContactList->clear();
        ui->UserContactList->addItems(doublelist->ContactsToAdd);
    }
}
