/*
** EPITECH PROJECT, 2020
** B-CPP-500-MAR-5-1-babel-adrien.delestrade
** File description:
** Database
*/

#include "../include/Database.hpp"
#include <uuid/uuid.h>

Database::Database()
{

}

Database::~Database()
{
}

std::string Database::Idgenerate()
{
    char chaine[256];
    uuid_t binuuid;
    memset((char *)chaine, 0, 128);
    uuid_generate_random(binuuid);
    uuid_unparse_lower(binuuid, (char *)chaine);
    return ((std::string)chaine);
}

int Database::setNewUser(std::string UserName, std::string UserID, std::string Password)
{
    User *newUser = new User();
    newUser->setUsername(UserName);
    newUser->setUserID(UserID);
    newUser->setPassWord(Password);
    newUser->setConectionStatement("connected");
    std::map<std::string, User*> NewMapUser;
    NewMapUser[UserID] = newUser;
    _users.insert(std::pair<std::string, User*>(UserID, newUser));
    return 0;
}

void Database::SaveState(User* user, std::ofstream &myfile)
{
    if(user->getConectionStatement() == "connected")
        myfile << "#state#\n" << "connected\n";
    else
        myfile << "#state#\n" << "disconnected\n";
}

std::string Database::UserDisconect(std::string Username)
{
    std::cout << "I'm here\n";
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it)
        if(it->second->getUsername() == Username) {
            it->second->setConectionStatement("disconnected");
            return "User_disconnected";
        }
    return "User_disconnected";
}

void Database::saveDB()
{
    std::cout << "I'm safe\n";
    std::ofstream myfile ("../Database/src/save.txt", std::ios::out);
    if (myfile.is_open()) {
        for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users. end(); ++it) {
            myfile << "#User#\n";
            myfile << it->first << "|" << it->second->getUsername() << "|" << it->second->getPassword() << '|' << '\n';
            SaveState(it->second, myfile);
            //suite saveit->second->getContact(it->first, it->second, myfile);
        }
        myfile << "#ENDSAVE#";
        myfile.close();
    }
    else std::cout << "Unable to open file";
}

int Database::UserAlreadyexist(std::string Username)
{
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it)
        if(it->second->getUsername() == Username)
            return 1;
    return 0;
}

std::string Database::getUSerPassWord(std::string UserName)
{
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it)
        if(it->second->getUsername() == UserName) {
            return it->second->getPassword();
        }
    return "No Password";
}

std::string Database::list_users()
{
    std::string Userlist;
    for (std::map<std::string, User*>::iterator it=_users.begin(); it!=_users.end(); ++it) {
        Userlist = Userlist + it->second->getUsername();
        Userlist = Userlist + '|';
    }
    return Userlist;
}


/*
int main()
{
    IDatabase *data = new Database();
    //data->display();
    
    
    
    
    data->loadSaveDB();
    
    
    
    std::cout << "----------------------- "<< std::endl;
    //data->setNewUser("Manon", "1");
    //data->setNewUser("Amel", "2");
    //data->setNewUser("Adrien", "3");
    //data->newContact("1", "2");
    //data->newContact("2", "1");
    //data->newContact("2", "3");
    //data->newContact("3", "2");
    //data->NewMessage("1", "2", "CouCou|S");
    //data->NewMessage("2", "1", "CouCou|R");
    //data->NewMessage("2", "1", "CouCou Manon|S");
    //data->NewMessage("1", "2", "CouCou Manon|R");
    //data->NewMessage("1", "2", "Ca va?|S");
    //data->NewMessage("2", "1", "Ca va?|R");
    //data->display();
    //data->displayConv("999", "111");
    //data->saveDB();
    
    return 0;
}
*/